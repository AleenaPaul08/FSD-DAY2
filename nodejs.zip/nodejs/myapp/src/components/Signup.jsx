import { Button, TextField, Typography } from '@mui/material'
import React from 'react'

function Signup() {
  return (
    <div>
        <Typography variant='h4'>Sign Up</Typography>
        <br /><br />
        <TextField variant='outlined' label='Name'/>
        <br /><br />
        <TextField variant='outlined' label='Place'/>
        <br /><br />
        <TextField variant='outlined' label='Age'/>
        <br /><br />
        <TextField variant='outlined' label='Gender'/>
        <br /><br />
        <TextField variant='outlined' label='Email'/>
        <br /><br />
        <TextField variant='outlined' label='Password' type='password'/>
        <Button variant='contained'>Submit</Button>
    </div>
  )
}

export default Signup