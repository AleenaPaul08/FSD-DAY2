import React, { useState } from 'react'

const Mapping = () => {  
    var [names,setNames] = useState(["Aleena","Hepsy","Jaiby","Merin"])

  return (
    <div>
        <ul>
            {names.map((value,index)=>{
                return(
                    <li>{value}</li>
                )
            })}
        </ul>
    </div>
  )
}

export default Mapping