import { Button, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'

const UseE = () => {
    var [name,SetName] = useState()

    const changeHName = ()=>{
        SetName("Home")
    }
    
    const changeCname = ()=>{
        SetName("Contact")
    }

    const changeGname = ()=>{
        SetName("Gallery")
    }

    useEffect(()=>{
        changeHName()
    },[])
  return (
    <div>
        <Typography>Welcome To {name}</Typography>
        <Button variant='contained' onClick={changeHName}>Home</Button>&nbsp;&nbsp;
        <Button variant='contained' onClick={changeCname}>Contact</Button>&nbsp;&nbsp;
        <Button variant='contained' onClick={changeGname}>Gallery</Button>&nbsp;&nbsp;

    </div>
  )
}

export default UseE