import { Button, TextField, Typography } from '@mui/material'
import React from 'react'

const Login = () => {
  return (
    <div>
        <Typography variant='h4'>Hello</Typography>
        <TextField variant='outlined' label='username'/>
        <Button>Submit</Button>
    </div>
  )
}

export default Login